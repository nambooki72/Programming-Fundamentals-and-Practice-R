#include <stdio.h>
int main(void)
{
	char code1 = 'A';
	char code2 = 65;
	printf("code1=%C , code1=%d\n", code1, code1);
	printf("code2=%C , code2=%d\n", code2, code2);
	return 0;
}