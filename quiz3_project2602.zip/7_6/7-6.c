#include<stdio.h>

int main(void)
{

	int i, j;

	for (i = 1;i <= 7;i++)
	{
		for (j = 1;j <= i;j++)
		{
			printf("%d", j);

		}
		for (j = 7 - i;j >= 1 ;j--)
		{
			printf("*");
		}
		printf("\n");
		
	}

	return 0;
}