#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
	int i, j, n;

	printf("1~9������ ���� �Է��Ͻÿ�?");
	scanf("%d", &n);

	for (i = 1;i <= n;i++)
	{
		
		for (j = n;j >= 1;j--)
		{
			if ( i==1 || i==n || j==1 || j==n)
			{
				printf("%d", j);
			}
			else
			{
				printf(" ");
			}
		}
		printf("\n");
	}


	return 0;
}