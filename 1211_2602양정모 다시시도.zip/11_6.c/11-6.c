#include <stdio.h>
int main()
{
	char* ptr = "COMPUTER";
	int i;
	for (i = 7; i >= 0; i--)
		printf("%s\n", ptr + i);
	for (i = 0;i <= 7; i++)
		printf("%s\n", ptr + i);
	return 0;
}