#include <stdio.h>

int main(void)
{
	int x, y;


	for (y = 0;y < 5;y++)
	{
		for (x = 0;x < y+1;x++)
		{
			printf("*");
		}
		printf("\n");
	}



	return 0;
}