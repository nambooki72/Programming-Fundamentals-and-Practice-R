#include <stdio.h>

void matrix(int array[3][3], int row);

int main(void)
{
	int i, j, n = 0;
	int a[3][3], b[3][3];
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			a[i][j] = ++n;
			b[i][j] = 0;
		}
	}
	for (i = 0; i < 3; i++) //b�� �迭 �� ����
	{
		for (j = 0; j < 3; j++)
		{
			b[3- 1 - j][i] = a[i][j];
		}
	}

	printf("A=\n");
	matrix(a, 3);

	printf("B=\n");
	matrix(b, 3);

	return 0;
}

void matrix(int array[3][3], int row)
{
	int i, j;
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < 3; j++)
		{
			printf(" %3d", array[i][j]);
			if (j == 2) printf("\n");
		}
	}
}