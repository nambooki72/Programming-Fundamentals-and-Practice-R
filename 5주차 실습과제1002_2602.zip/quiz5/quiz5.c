#include <stdio.h>
int main(void)
{
	int i = 1, j = 2, k = 3, m = 4;
	j *= k + 3;
	printf(" % d \n", j); //j=j*(k+3) = 12
	i += j + k;
	printf(" % d \n", i); //i=i+j+k 1 + (12 + 3) = 16
	j *= k = m + 5;
	printf(" % d \n", j); // j*=(k=(m+5)) j = j*(k=(m+5)) k=9 12x9= 108
	return 0;
}