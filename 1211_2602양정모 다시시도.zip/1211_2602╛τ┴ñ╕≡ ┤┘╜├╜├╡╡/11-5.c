#include <stdio.h>
int main()
{
	char ch[] = "Computer";
	char* str = "Computer";
	int i;
	for (i = 0; i < 8; i++) {
		printf("ch[%d] = %c, ", i, ch[i]);
		printf("*(str+%d) = %c\n", i, *(str + i));
	}
	return 0;
}