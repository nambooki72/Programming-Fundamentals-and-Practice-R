#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main()
{

	char x, y, z;
	
	scanf("%c %c %c", &x, &y, &z);

	printf("x=%c\ny=%c\nz=%c\n", x, y, z);
	return 0;






}