#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main()
{
	char* month[] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
	int mon;
	printf("���� �Է��ϼ��� : ");
	scanf("%d", &mon);
	printf("%d�� : %s\n", mon, month[mon-1]);
	return 0;
}