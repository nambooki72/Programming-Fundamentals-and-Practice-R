#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int even(int n);
int absolute(int n);
int sign(int n);

int main(void)
{

	int n;

	printf("������ �Է��ϼ��� :");
	scanf("%d", &n);

	printf("even()�� ��� : %d \n", even(n));
	printf("absolute()�� ��� : %d \n", absolute(n));

	printf("sign()�� ��� : %d \n", sign(n));



	return 0;
}



int even(int n)
{
	int result;

	if (n % 2 == 0)
		result = 1;
	else
		result = 0;

	return result;

}



int absolute(int n)
{

	int result;

	if (n < 0)
		result = -n;
	else
		result = n;

	return result;


}


int sign(int n)
{
	int result;

	if (n < 0)
		result = -1;
	else if (n > 0)
		result = 1;
	else
		result = 0;

	return result;


}

/*


#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int even(int n);
int absolute(int n);
int sign(int n);

int main(void)
{

	int n;

	printf("������ �Է��ϼ��� :");
	scanf("%d", &n);

	printf("even()�� ��� : %s \n", even(n) ? "¦��" : "Ȧ��");
	printf("absolute()�� ��� : %d \n", absolute(n));

	printf("sign()�� ��� : ");
	if (sign(n) == 1)
		printf("��� \n");
	else if (sign(n) == 0)
		printf("�� \n");
	else
		printf("���� \n");


	return 0;
}



int even(int n)
{
	int result;
	
	if (n % 2 == 0)
		result = 1;
	else
		result = 0;

	return result;

}



int absolute(int n)
{

	int result;

	if (n < 0)
		result = -n;
	else
		result = n;

	return result;


}


int sign(int n)
{
	int result;

	if (n < 0)
		result = -1;
	else if (n > 0)
		result = 1;
	else
		result = 0;

	return result;


}


*/