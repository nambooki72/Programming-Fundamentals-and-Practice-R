#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void swapstring(char* x, char* y, int size);

int main()
{
	char a[] = "Banana";
	char b[] = "Orange";

	printf("��ȯ �� : a = %s, b= %s \n", a, b);
	swapstring(a, b, sizeof(a)/sizeof(char)); //6

	printf("��ȯ �� : a = %s, b= %s \n", a, b");
	return 0;

}

void swapstring(char* x. char* y, int size)
{
	int i;
	char temp;

	for (i = 0;i < size;i++)
	{
		temp = x[i];
		x[i] = y[i];
		y[i] = temp;
	}
}