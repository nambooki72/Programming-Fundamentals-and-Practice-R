#include <stdio.h>

int main(void)
{
	int x, y;


	for (y = 0;y < 5;y++)
	{
		for(x=0;x<10;x++)
		{
			printf("*");
		}
		printf("\n");
	}



	return 0;
}