#include <stdio.h>

void matrix(int array[][4], int row); // �Լ� ����

int main(void)
{
    int i, j, n = 0;
    int a[4][4], b[4][4];

    // �迭 �ʱ�ȭ
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            a[i][j] = ++n;
            b[i][j] = 0;
        }
    }

    // b�� �迭 �� ����
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            b[4 - 1 - j][i] = a[i][j];
        }
    }

    printf("A=\n");
    matrix(a, 4);  // �ùٸ� �Լ� ȣ��
    printf("B=\n");
    matrix(b, 4);  // �ùٸ� �Լ� ȣ��

    return 0;
}

void matrix(int array[][4], int row)
{
    int i, j;
    for (i = 0; i < row; i++)
    {
        for (j = 0; j < 4; j++)
        {
            printf(" %3d", array[i][j]);
            if (j == 3) printf("\n");
        }
    }
}