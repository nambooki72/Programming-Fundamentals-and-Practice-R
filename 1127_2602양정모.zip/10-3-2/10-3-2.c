#include <stdio.h>

void transpose(int a[][3], int b[][3], int n)
{
	int r, c;
	for (r = 0; r < n; r++)
		for (c = 0; c < n; c++)
			b[r][c] = a[c][r];
}

void print(int a[][3], int n)
{
	int r, c;
	for (r = 0; r < n; r++) {
		for (c = 0; c < n; c++)
			printf("%d ", a[r][c]);
		printf("\n");
	}
}

int main(void)
{
	int A[3][3] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
	int B[3][3];
	transpose(a[][3], b[][3], 3);

	printf("A=\n");
	print(a[][3], 3);

	printf("B=\n");
	print(b[][3], 3);

	return 0;
}