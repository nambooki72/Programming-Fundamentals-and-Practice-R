#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>



main()
{
	int num1, num2, num3, num4, max, max_1, max_2, min_1, min_2, min;
	printf("4���� ������ �Է� : ");
	scanf("%d%d%d%d", &num1, &num2, &num3, &num4);


	max_1 = (num1 > num2) ? num1 : num2;
	max_2 = (num3 > num4) ? num3 : num4;
	
	max = (max_1 > max_2) ? max_1 : max_2;

	min_1 = (num1 > num2) ? num2 : num1;
	min_2 = (num3 > num4) ? num3 : num4;

	min = (min_1 > min_2) ? min_2 : min_1;

	printf("�ִ밪 : %d, �ּҰ� : %d\n", max, min);
}