#include <stdio.h>
int main(void)
{
	int i = 10;
	int* pi = &i;
	printf("i = %d, pi = %p\n", i, pi);
	(*pi)++;
	printf("i = %d, pi = %p\n", i, pi);
	printf("i = %d, pi = %p\n", i, pi);
	*pi++;
	printf("i = %d, pi = %p\n", i, pi);
	return 0;
}

/*
i = 10, pi = 0000006A1D30F964
i = 11, pi = 0000006A1D30F964
i = 11, pi = 0000006A1D30F964
i = 11, pi = 0000006A1D30F968
*/