//�����Ϳ� �迭 �ε��� 2������ �Լ��� Ȱ���غ���

#include <stdio.h>
int get_sum(int a[], int n);
int main(void)
{
	int data[] = { 10, 20, 30, 40, 50 };
	int value;
	value = get_sum(data, 5);
	printf("%d \n", value);
	return 0;
}
int get_sum(int a[], int n)
{
	int i;
	int sum = 0;
	for (i = 0; i < n; i++)
		sum += a[i];
	return sum;
}

/*
* 
#include <stdio.h>

int get_sum(int *p, int n);

int main(void)
{
int data[] = { 10, 20, 30, 40, 50 };
int value;
value = get_sum(data, 5);
printf("%d \n", value);
return 0;
}
int get_sum(int *p, int n)
{
int i;
int sum = 0;
for (i = 0; i < n; i++)
sum += *(p+i);
return sum;
}

*/