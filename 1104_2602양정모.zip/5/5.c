#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>


void Intro(void);
int Input(void);
int Add(int a, int b);
void Result_Print(int a);


int main(void)
{
	int a, b;
	int output;

	Intro();

	a = Input();
	b = Input();

	// Add �Լ� ����
	output = Add(a, b);

	// Result_Print �Լ� ����
	Result_Print(output);




	//============================
	output = 0;

	printf("\n\n\n");
	Intro();

	a = Input();
	b = Input();


	output = Add(a, b);

	Result_Print(output);

	return 0;
}


void Intro(void)
{
	// Intro �Լ� ����
	printf(" ======= START ======== \n");
	printf(" �� ���� ���� �Է� : \n");
}



int Input(void)
{
	int ip;
	scanf("%d", &ip);
	return ip;
}



int Add(int a, int b)
{
	return a + b;
}


void Result_Print(int val)
{
	printf("������ ���� ��� : %d \n", val);
	printf(" ======= END ======== \n");
}