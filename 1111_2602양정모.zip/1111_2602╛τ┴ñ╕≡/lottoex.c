#include <stdio.h>
#include <stdlib.h>



int main(void)
{


	int i;
	srand((unsigned)time(NULL));


	for (i = 0;i < 6;i++)
	{
		printf("%d ", (rand() % 45) + 1);
	}




	return 0;
}