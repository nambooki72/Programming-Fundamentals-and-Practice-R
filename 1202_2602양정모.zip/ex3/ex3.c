#include <stdio.h>

int main(void)
{
	char* pc; char a = 'A';
	int* pi; int b = 1;
	double* pd; double c = 1.5;
	pc = &a;
	pi = &b;
	pd = &c;
	printf("���� �� pc = %p, pi = %p, pd = %p\n", pc, pi, pd);
	//(*pi)++; //��: *pi++
	//printf("b=%d,pi= %p \n", b, pi);

	pc++;
	pi++;
	pd++;

	printf("���� �� pc = %d, pi = %d, pd = %d\n", pc, pi, pd);
	return 0;
}