#include <stdio.h>
int main(void)
{
	int x = 10;
	printf(��1 % d\n", x++);//
		printf(��2 % d\n", x);//
			printf(��3 % d\n", --x);//
				printf(��4 % d\n", x);//
					return 0;
}