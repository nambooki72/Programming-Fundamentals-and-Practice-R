#include<stdio.h>

int main(void)
{
	int i, j, sum=0;

	for (i = 10;i <= 30;i++)
	{
		for (j = 1;j <= 5;j++)
		{
			sum += i * j;
		}
	}

	printf("%d", sum);

	return 0;
}