extern int all_files;
extern int this_file;


void sub(void)
{
	all_files = 10;
	this_file=200;
}